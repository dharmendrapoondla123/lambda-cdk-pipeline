def handler(event, context):
    return {
        "statusCode": 200,
        "body": "Hello testing from CDK-deployed Lambda!"
    }
